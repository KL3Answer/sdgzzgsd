#!/bin/bash
#
#        DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#                    Version 2, December 2004
#
# Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
#
# Everyone is permitted to copy and distribute verbatim or modified
# copies of this license document, and changing it is allowed as long
# as the name is changed.
#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
#
#  0. You just DO WHAT THE FUCK YOU WANT TO.

# usage
usage(){
    echo -e "Usage: $0 [OPTIONS]"
    echo -e " -h --help  display help info ."
    echo -e " -b  set up base dir(use current dir as base dir by defualt) ."
    echo -e " -p  set up pb file base dir(use '{current dir}/proto' as base dir by defualt) ."
    echo -e $gst" -f  set up pb file dir(compulsory) ."$cend
    echo -e " -j  set up jav out put file dir('src/main/java' by default) ."
    echo -e " -c  check command id ."
    echo -e '--------------\n'
    echo -e "example:\n"
    echo -e "bash ./pbHelper.sh -f TestCommand.proto"
    echo -e '\n-----EOF------'
    exit 0
}

# basic styles
att='\033[32;5m=====> \033[0m'
rst='\033[31m'
gst='\033[32m'
yst='\033[33m'
pst='\033[35m'
cend='\033[0m'

# check whether exist conflict of command id
# $1 -> pb file $2 pb file path
checkCommandId(){
    echo -e $yst'...start checking command id'$cend

    sline=`getCMDTypeSTLine $1`;let sline++
    eline=`getCMDTypeEDLine $1 $sline`;let eline--
    commandid=(`sed -n $sline","$eline"p" $1|sed s/[[:space:]]//g |  awk -F '[=;]' '{print $2}'`)

    # traverse all pb files
    allpbfiles=(`ls $2| grep '.proto' |grep -v ${1##*/}`)
    for var in ${allpbfiles[@]} ; do
        fullpath=$2'/'$var
        # get cmdType line
        st=`getCMDTypeSTLine $fullpath`
        # ignore not matched
        if [ -z "$st" ]
        then
            echo -e $yst'...'$var' finished(all good)'$cend
            continue
        fi
        let st++
        ed=`getCMDTypeEDLine $fullpath $st`;let ed--

        # get all command id
        oldcid=(`sed -n $st","$ed"p" $fullpath|sed s/[[:space:]]//g |  awk -F '[=;]' '{print $2}'`)
        for cid in ${oldcid[@]} ; do
            # compare with the new pb command ids
            for ncid in ${commandid[@]} ; do
                if [ $cid == $ncid ];then
                    echo -e $rst'command id conflict!('$var':'$cid')\n...exiting' $cend
                    exit 1
                fi
            done
        done
        echo -e $yst'...check '$var' commands finished(all good)'$cend
    done
    echo -e $yst'...all command id check finished(all good)'$cend
}

# $1 pbFullPath
getCMDTypeSTLine(){
   echo `grep -nE 'enum\s*CmdType\s*{.*' -m 1 $1 | cut -d ":" -f 1`
}

# $1 pbFullPath $2 start line
getCMDTypeEDLine(){
    echo `cat $1 |sed -n "/}.*/=" | awk '{if($0>'$2'){print $0;exit}}'`
}

# $1 pbFullPath
getAllCMDTypeName(){
    sline=`getCMDTypeSTLine $1`
    let sline++
    eline=`getCMDTypeEDLine $1 $sline`
    let eline--

    echo `sed -n $sline","$eline"p" $1| sed s/[[:space:]]//g |  awk -F '=' '{print $1}'`
}

# $1 pbFullPath
getAllMessages(){
    echo `awk '{if(index($0,"message")&&(e=index($0,"{")))print substr($0,8,e-8) }' $1`
}

# $1 pbFullPath $2 pname
getProtoClassName(){
    pkg=`grep "^package" $1 -m 1 |sed s/[[:space:]]//g`
    pkg=${pkg:7}
    pkg=${pkg%\;*}
    pbClass=$pkg'.'$2
    echo $pbClass
}

isLinux(){
    echo `uname -a|grep -o 'Linux'`
}


# 0.0 check the version of protoc(2.5.0 only because pb file can not compiled correctly under other versions)
protocV=`protoc --version`
if [ "$protocV" != "libprotoc 2.5.0" ]
then
    echo -e $rst'the version of protoc is not 2.5.0('$protocV')\n...exiting'$cend
    exit 0
fi

# 0.1 check os version
islinux=`isLinux`

# 1.0 set up args
basedir=`cd $(dirname $0); pwd -P`
javaOutput='src/main/java'
pbFileisSet=''
checkCID=''
while [ -n "$1" ]; do
    case $1 in
        -h|--help) usage;shift 1 ;;
        -b) if [ "$2" != "" ];then basedir=$2;else echo -e $rst'base dir can not be empty!\n...exiting'$cend;exit 0;fi;shift 2;;# setup basedir
        -p) if [ "$2" != "" ];then pbBasedir=$2;else echo -e $rst'pb file base dir can not be empty!\n...exiting'$cend;exit 0;fi;shift 2;;# setup pb basedir
        -f) if [ "$2" != "" ];then pbFullPath=$2;pname=${2%%.*};pbFileisSet='1';else echo -e $rst'the name of pb file can not be empty!\n...exiting'$cend;exit 0;fi;shift 2;;# set up pb file name
        -j) if [ "$2" != "" ];then javaOutput=$2;else echo -e $rst'java output dir can not be empty!\n...exiting'$cend;exit 0;fi;shift 2;;# create or edit pb file
        -c) checkCID="1"; shift 1;;# check command id
        -*) echo "error: no such option $1. -h for help";exit 1;;
        *) break;;
    esac
done

# 1.1 check pb file
if [ -z "$pbFileisSet" ];then echo -e $rst'proto file is not set(use -f)\n...exiting'$cend;exit 0;fi;
# 1.2 setup templates dir
tpldir=$basedir'/templates'
# 1.3 set up default proto base dir
if [ -z "$pbBasedir" ];then pbBasedir=$basedir"/proto";fi;
# 1.4 set up pb file fill path
pbFullPath=$pbBasedir'/'$pbFullPath
#end 1

echo $basedir'--'$pbBasedir'+'$pbFullPath

# 2.0 args
echo -e '1) base dir:'$pst$basedir$cend
echo -e '2) pb base dir:'$pst$pbBasedir$cend
echo -e '3) pb file path:'$pst$pbFullPath$cend
echo -e '4) java output dir:'$pst$javaOutput$cend
#end 2

# 3.0 create or edit pb file
if [ ! -f $pbFullPath ]
then
    #create by template or ont
	if [ -f $tpldir'/t.proto' ]
	then
	    #use template
	    cp $tpldir'/t.proto' $pbFullPath
	else
	    touch $pbFullPath
	fi
	echo -e $yst'...new pb file is created'$cend
	#must be edited
	vim $pbFullPath
else
    echo -ne $att$gst'edit pb file ?[y/n]:'$cend
    if  read -t 5 isEdit
    then
        if [ "$isEdit" = 'y' ]
        then
            vim $pbFullPath
        else
            echo -e $yst'...the pb file is not edited'$cend
        fi
    else
           echo -e $yst'\n... the pb file is not edited'$cend
    fi
fi
#end 3

# 4.0 compile pb 
# 4.1 check conflict
if [ -n "$checkCID" ] ;then checkCommandId $pbFullPath $pbBasedir ; fi
# 4.2 compile
protoc -I=$pbBasedir --java_out=$javaOutput $pbFullPath
#end 4

# 5.0 add CmdBean
# 5.1 get name of the PB cmd Class
cmdPkg="com.gexin.rp.cm.protocol.gx.command.gt"
cmdName=$pname'Cmds'
cmdClassname=$cmdPkg'.'$cmdName
echo -ne '5) the default name of the pb class:'$pst$cmdClassname$cend'\n'$att$gst'the new name of pb cmd class?[enter to skip]:'$cend
if read -t 5 newPbClassname
then
    if [ "$newPbClassname" != "" ]
    then
        cmdClassname=$newPbClassname
    fi
    echo -e '6) the name of pb cmd class:'$pst$cmdClassname$cend
else
    echo -e '\6) the name of pb cmd class:'$pst$cmdClassname$cend'\n'
fi
# 5.2 the pb cmd class exist or not
cmdClassFilePath=$basedir'/'$javaOutput'/'${cmdClassname//'.'/'/'}'.java'
if [ ! -f $cmdClassFilePath ]
then 
	#create
	echo -e $yst'...creating'$cend
	if [ -f $tpldir'/t.java' ]
	then
	    # use template
	    cp $tpldir'/t.java' $cmdClassFilePath

	    # get pkg of proto
        pbClass=`getProtoClassName $pbFullPath $pname`
        # replace package name ,class name ,uid
        if [ -n "$islinux" ]
        then
	        sed -i -e 's/${PACKAGE}/'$cmdPkg'/g' -e 's/${PROTO}/'$pbClass'/g' -e 's/${CMD}/'$cmdName'/g' -e 's/${UID}/'`date +%s`'/g' $cmdClassFilePath
        else
	        sed -i '' -e 's/${PACKAGE}/'$cmdPkg'/g' -e 's/${PROTO}/'$pbClass'/g' -e 's/${CMD}/'$cmdName'/g' -e 's/${UID}/'`date +%s`'/g' $cmdClassFilePath
        fi
        # add message key and value
        messagek=(`getAllCMDTypeName $pbFullPath`)
        message=(`getAllMessages $pbFullPath`)
        #use template
        beantpl=`grep -nE '//add\\(new CmdBean' $cmdClassFilePath -m 1`
        insertln=`echo $beantpl| cut -d ':' -f 1`
        beantpl=${beantpl#*//}

        # match by order
        for((i=0;i<${#messagek[@]};i++));do
            var=`echo $beantpl |sed -e 's/${CMD_TYPE}/'${messagek[i]}'_VALUE/g' -e 's/${PNAME}/'$pname'/g' -e 's/${MESSAGE}/'${message[i]}'/g'`
            # add cmd bean
            if [ -n "$islinux" ]
            then
                sed -i $insertln' a\ \ \ \ \ \ \ \ \ \ \ \ '"$var"  $cmdClassFilePath
            else
                sed -E -i '' $insertln' a\
                \ \ \ \ \ \ \ \ \ \ \ \ '"$var"'
                '  $cmdClassFilePath
            fi
        done
	else
	    touch $cmdClassFilePath
	fi

	echo -e $yst'...create cmd class finished'$cend
else
    # add message key and value
    messagek=(`getAllCMDTypeName $pbFullPath`)
    message=(`getAllMessages $pbFullPath`)

    #insert import
    pbClass=`getProtoClassName $pbFullPath $pname`
    hasImport=`grep import $cmdClassFilePath |grep $pbClass'.CmdType' -m 1`
    if [ -z "$hasImport" ]
    then
        i=`grep -n '^import' $cmdClassFilePath -m 1 |cut -d ':' -f 1`
        if [ -n "$islinux" ]
        then
            sed -i -e $i' a\'"import $pbClass;" -e $i' a\'"import $pbClass.CmdType;" $cmdClassFilePath
        else
            echo '---------3'
            sed -i '' -e $i' a\
            import '"$pbClass;" -e $i' a\
            import '"$pbClass.CmdType;" $cmdClassFilePath
        fi
    fi
    #find last
    beantpl=`grep -nE 'add\\(new CmdBean' $cmdClassFilePath |tail -n 1`
    insertln=`echo $beantpl| cut -d ':' -f 1`
    # match by order
    for((i=0;i<${#messagek[@]};i++));do
        k=${messagek[i]}
        v=${message[i]}
        exist=`grep "$k"_VALUE $cmdClassFilePath -m 1`
        if [ -z "$exist" ]
        then
            var='add(new CmdBean(CmdType.'$k'_VALUE, '$pname'.'$v'.class));'
            if [ -n "$islinux" ]
            then
                sed -i $insertln' a\ \ \ \ \ \ \ \ \ \ \ \ '"$var"  $cmdClassFilePath
            else
                echo '----------4'
                sed -i '' $insertln' a\
                \ \ \ \ \ \ \ \ \ \ \ \ '"$var"'
                '  $cmdClassFilePath
            fi
        fi
    done

    echo -e $yst'...edit cmd class file finished'$cend
fi
# 5.3 edit or not
echo -ne $att$gst'edit the cmd class file?[y/n]:'$cend
if read -t 5 editJava
then
    if [ "$editJava" = 'y' ]
    then
        vim $cmdClassFilePath
    fi
else
    echo ''
fi
#end 5

# 6.0 modify GtCmdInit ,add cmd to list
gtcmd=`find $basedir -name GtCmdInit.java`
if [ -z "$gtcmd" ]
then
    echo -e $rst'GtCmdInit.Java not found\n...exiting'$cend
fi
echo '7) add cmd to cmdList of GtCmdInit'

#repeat or not
exist=`grep $cmdName $gtcmd -m 1`
if [ -n "$exist" ]
then
    echo -e $yst'...cmd already added'$cend
else
    ln=(`cat $gtcmd |sed -n '/InnerCommandImpl.addCmdList/='`)
    i=${#ln[@]}

    if [ -n "$islinux" ]
    then
        sed -i ${ln[i-1]}' a\ \ \ \ \ \ \ \ InnerCommandImpl.addCmdList('"$cmdName"'.cmds);//add by pbHelper'  $gtcmd
    else
        sed -i '' ${ln[i-1]}' a\
        \ \ \ \ \ \ \ \ InnerCommandImpl.addCmdList('"$cmdName"'.cmds);//add by pbHelper
        ' $gtcmd
    fi

    # get import line num
    importlineN=`sed -n '/^import/=' $gtcmd |tail -n 1`
    # add import
    if [ -z "$importlineN" ]
    then
        echo -e $rst'...no imports found in GtCmdInit.Java?'$cend
    else
        if [ -n "$islinux" ]
        then
            sed -i $importlineN' a\'"import $cmdClassname;" $gtcmd
        else
            sed -i '' $importlineN' a\
            '"import $cmdClassname;" $gtcmd
        fi
    fi

    echo -e $yst'...cmd add successfully'$cend
fi
#end 6

echo -e $yst'all process finished\nexiting...'$cend
