package ${PACKAGE};

import java.util.ArrayList;
import java.util.List;

import ${PROTO};
import ${PROTO}.CmdType;
import com.gexin.rp.cm.protocol.gx.command.base.CmdBean;

public class ${CMD} {

	public static final List<CmdBean> cmds = new ArrayList<CmdBean>() {

		private static final long serialVersionUID = ${UID}L;

		{
			//add(new CmdBean(CmdType.${CMD_TYPE}, ${PNAME}.${MESSAGE}.class));
		}
	};

}

